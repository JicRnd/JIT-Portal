#!/usr/bin/env python3
"""Reusable VS Code AI project onboarding wizard."""

import argparse, json, shutil, datetime as dt
from pathlib import Path

def ask(q, default="", required=False):
    while True:
        s = input(f"{q}" + (f" [{default}]" if default else "") + ": ").strip()
        if not s:
            s = default
        if s or not required:
            return s
        print("Required.")

def yesno(q, default=True):
    while True:
        s = input(f"{q} [{'Y/n' if default else 'y/N'}]: ").strip().lower()
        if not s:
            return default
        if s in ("y","yes"): return True
        if s in ("n","no"): return False

def many(q):
    print(q)
    print("One item per line; blank line finishes.")
    out=[]
    while True:
        s=input("> ").strip()
        if not s: break
        out.append(s)
    return out

def collect():
    c={}
    c["project_name"]=ask("Project name", required=True)
    c["workspace"]=ask("Local VS Code project/control folder", required=True)
    c["purpose"]=ask("One-sentence project purpose")
    c["source_mode"]=ask("Source mode: local, remote, or mixed", "local", True).lower()
    if c["source_mode"] in ("remote","mixed"):
        c["remote"]={
            "alias": ask("SSH alias", required=True),
            "host": ask("Remote host/IP", required=True),
            "user": ask("Remote SSH user", required=True),
            "app_root": ask("Remote application root", required=True),
            "data_root": ask("Remote data/storage root (optional)"),
            "reboot_approval": yesno("Require explicit approval before reboot", True),
        }
    c["startup"]=many("Startup chain / entry points")
    c["healthy"]=many("Healthy-state checks")
    c["ports"]=many("Important ports/services")
    c["components"]=many("Important components and responsibilities")
    c["excluded"]=many("Paths/files agents should normally ignore")
    c["risky_files"]=many("High-risk files/components")
    c["risky_actions"]=many("Actions requiring explicit approval")
    c["testing"]=many("Normal testing/restart/verification procedures")
    c["rules"]=many("Other critical rules")
    return c

def bullets(xs):
    return "\n".join(f"- {x}" for x in xs) if xs else "- None documented."

def backup(path, root):
    if path.exists():
        root.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, root/path.name)

def put(path, text, bdir):
    path.parent.mkdir(parents=True, exist_ok=True)
    backup(path,bdir)
    path.write_text(text.rstrip()+"\n",encoding="utf-8")

def build(c):
    root=Path(c["workspace"]).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    bdir=root/".installer_backups"/dt.datetime.now().strftime("%Y%m%d-%H%M%S")

    remote=""
    if c["source_mode"] in ("remote","mixed"):
        r=c["remote"]
        remote=f"""- SSH alias: `{r['alias']}`
- Remote target: `{r['user']}@{r['host']}`
- Remote application root: `{r['app_root']}`
"""
        if r.get("data_root"):
            remote += f"- Remote data root: `{r['data_root']}`\n"

    agents=f"""# {c['project_name']} AI Playbook

Keep this file short; it is always-on AI context.

## Identity
- Project: `{c['project_name']}`
- Purpose: {c.get('purpose') or 'See detailed docs.'}
- Local workspace: `{c['workspace']}`
- Source mode: `{c['source_mode']}`
{remote}
## Token discipline
- Load only task-relevant context.
- Do not inventory the entire project/remote system unless required.
- Respect `docs/context-exclusions.md`.
- Prefer paths and symbol names over whole-file copies.
- Prefer concise summaries over raw terminal output.
- Read detailed docs only when relevant.

## Detailed references
- `docs/architecture.md`
- `docs/startup-and-testing.md`
- `docs/safety-rules.md`
- `docs/context-exclusions.md`
{"- `docs/remote-system.md`" if c["source_mode"] in ("remote","mixed") else ""}

## High-risk routing
For high-risk work:
1. Orchestrator analyzes first.
2. Back up before modification when practical.
3. Make the smallest possible change.
4. Verify behavior.
5. Require explicit approval for approval-required actions.
"""

    architecture=f"""# {c['project_name']} Architecture

## Startup chain
{bullets(c['startup'])}

## Important components
{bullets(c['components'])}

## Ports/services
{bullets(c['ports'])}
"""

    testing=f"""# {c['project_name']} Startup and Testing

## Healthy-state checks
{bullets(c['healthy'])}

## Normal verification procedures
{bullets(c['testing'])}
"""

    safety=f"""# {c['project_name']} Safety Rules

## High-risk files/components
{bullets(c['risky_files'])}

## Actions requiring explicit approval
{bullets(c['risky_actions'])}

## Other critical rules
{bullets(c['rules'])}

## Defaults
- Back up high-risk files before replacement when practical.
- Make surgical changes rather than broad rewrites.
- Never store passwords in AI instructions.
- Never claim success without reasonable verification.
"""

    exclusions=f"""# {c['project_name']} Context Exclusions

Do not inspect/search these by default. Only access them when the current task requires it.

{bullets(c['excluded'])}
"""

    put(root/"AGENTS.md", agents, bdir)
    put(root/"docs"/"architecture.md", architecture, bdir)
    put(root/"docs"/"startup-and-testing.md", testing, bdir)
    put(root/"docs"/"safety-rules.md", safety, bdir)
    put(root/"docs"/"context-exclusions.md", exclusions, bdir)

    if c["source_mode"] in ("remote","mixed"):
        r=c["remote"]
        remote_doc=f"""# {c['project_name']} Remote System

- SSH alias: `{r['alias']}`
- Host: `{r['host']}`
- User: `{r['user']}`
- Application root: `{r['app_root']}`
- Data/storage root: `{r.get('data_root','')}`

## Rules
- Prefer SSH-key authentication.
- Never store passwords in AGENTS.md, prompts, or code.
- Prefer focused one-shot SSH commands over long interactive sessions.
- Fetch only task-relevant files.
{"- Reboot requires explicit user approval." if r.get("reboot_approval") else ""}
"""
        put(root/"docs"/"remote-system.md", remote_doc, bdir)

    settings={
        "chat.useAgentsMdFile": True,
        "search.exclude":{
            "**/.git/**":True,
            "**/__pycache__/**":True,
            "**/.venv/**":True,
            "**/venv/**":True,
            "**/node_modules/**":True
        }
    }
    put(root/".vscode"/"settings.json", json.dumps(settings,indent=4), bdir)
    put(root/"project-ai-config.json", json.dumps(c,indent=4), bdir)
    workspace=root/(c["project_name"].replace(" ","_")+".code-workspace")
    put(workspace, json.dumps({"folders":[{"path":"."}]},indent=4), bdir)

    print("\nCreated project AI workspace:")
    print(root)
    print("\nPortable config:")
    print(root/"project-ai-config.json")
    print("\nOpen the generated .code-workspace in VS Code and use your global AI Orchestrator.")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--config",type=Path)
    a=p.parse_args()
    if a.config:
        c=json.loads(a.config.read_text(encoding="utf-8"))
    else:
        c=collect()
    build(c)

if __name__=="__main__":
    main()
