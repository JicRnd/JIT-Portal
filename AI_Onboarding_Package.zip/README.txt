AI ONBOARDING PACKAGE

FILES

1. AI_SETUP_QUESTIONNAIRE_PROMPT.txt
Email this to a coworker. They paste it into a fresh ChatGPT conversation.
ChatGPT interviews them one question at a time, identifies their available
models/pricing, then builds a customized machine installer.

2. generic_machine_installer_template.py
Starting template for the machine-level installer. ChatGPT should customize
the model names and any machine-specific behavior after the questionnaire.

3. setup_ai_project.py
Reusable per-project onboarding wizard.

Run:
    python setup_ai_project.py

It asks project-specific questions and creates:
- AGENTS.md
- architecture notes
- startup/testing notes
- safety rules
- context exclusions
- optional remote-system documentation
- VS Code settings
- project-ai-config.json
- .code-workspace file

The saved project-ai-config.json makes the setup portable/rebuildable.

Rebuild:
    python setup_ai_project.py --config project-ai-config.json

WORKFLOW

NEW PERSON / COMPUTER:
Questionnaire -> ChatGPT interview -> customized machine installer -> run once.

NEW PROJECT:
Run setup_ai_project.py -> answer questions -> open generated workspace ->
use global AI Orchestrator.

The global orchestration team is normally installed once per computer.
Project-specific knowledge is generated separately for each project.
