#!/usr/bin/env python3
"""Generic machine-level VS Code multi-model AI installer template.

Have ChatGPT customize the three model constants using the user's actual
VS Code model availability and pricing before running this file.
"""
from pathlib import Path
import shutil, datetime as dt

ORCHESTRATOR_MODEL="REPLACE_WITH_ORCHESTRATOR_MODEL"
LIGHTWEIGHT_MODEL="REPLACE_WITH_LIGHTWEIGHT_MODEL"
CODING_MODEL="REPLACE_WITH_CODING_MODEL"

HOME=Path.home()
DIR=HOME/".copilot"/"agents"
BACKUP=HOME/".copilot"/"agent-backups"/dt.datetime.now().strftime("%Y%m%d-%H%M%S")

def save(path,text):
    if path.exists():
        BACKUP.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,BACKUP/path.name)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text.rstrip()+"\n",encoding="utf-8")

orch=f"""---
name: AI Orchestrator
description: Cost-optimized primary coordinator.
model: {ORCHESTRATOR_MODEL}
tools: ['agent', 'todo']
agents: ['AI Lightweight Worker', 'AI Coding Worker']
user-invocable: true
disable-model-invocation: true
---

Delegate routine work to isolated workers.
Keep expensive reasoning for architecture, ambiguity, hard debugging, review, and escalation.
Pass workers only task-relevant context.
Require concise worker results.
"""

lite=f"""---
name: AI Lightweight Worker
description: Low-cost read/search worker.
model: {LIGHTWEIGHT_MODEL}
tools: ['read', 'search']
user-invocable: false
disable-model-invocation: false
---

Perform focused read-only research.
Respect AGENTS.md and exclusions.
Return concise findings only.
"""

code=f"""---
name: AI Coding Worker
description: Cost-efficient implementation worker.
model: {CODING_MODEL}
tools: ['read', 'search', 'edit', 'execute']
user-invocable: false
disable-model-invocation: false
---

Perform focused implementation and verification.
Respect AGENTS.md, safety rules, and exclusions.
Make minimal changes and escalate uncertainty.
"""

def main():
    DIR.mkdir(parents=True,exist_ok=True)
    save(DIR/"ai-orchestrator.agent.md",orch)
    save(DIR/"ai-lightweight-worker.agent.md",lite)
    save(DIR/"ai-coding-worker.agent.md",code)
    print("Installed global AI agents. Reload VS Code and select AI Orchestrator.")

if __name__=="__main__":
    main()
