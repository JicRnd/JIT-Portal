let catalog = null;
const $ = id => document.getElementById(id);

function fillSelect(el, values, labeler = x => x, includeBlank = false) {
  el.innerHTML = '';
  if (includeBlank) {
    const blank = document.createElement('option');
    blank.value = '';
    blank.textContent = '';
    el.appendChild(blank);
  }
  values.forEach(v => {
    const opt = document.createElement('option');
    if (typeof v === 'object') { opt.value = v.value; opt.textContent = v.label; }
    else { opt.value = v; opt.textContent = labeler(v); }
    el.appendChild(opt);
  });
}
function fmtMoney(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n.toLocaleString('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2}) : '—';
}
function boolFromYN(id) { return String($(id).value || '').toUpperCase() === 'Y'; }
function updateMountsForSeries() {
  const s = $('series').value;
  const previous = $('mount').value;
  const mounts = s ? ((catalog.series_mounts || {})[s] || []) : [];
  fillSelect($('mount'), mounts, x => x, true);
  if (mounts.includes(previous)) $('mount').value = previous;
}
function updateBores() {
  const s = $('series').value;
  const bores = s ? Object.keys(catalog.series[s] || {}).sort((a,b)=>Number(a)-Number(b)) : [];
  fillSelect($('bore'), bores, x => x, true);
  updateRods();
}
function updateRods() {
  const s=$('series').value, b=$('bore').value;
  const rods=(s && b) ? Object.keys((catalog.series[s]||{})[b]||{}).sort((a,b)=>Number(a)-Number(b)) : [];
  fillSelect($('rod_diameter'), rods, x => x, true);
}
function wireTabs() {
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.closest('.legacy-panel');
      parent.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
      parent.querySelectorAll('.tab-panel').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
      $(btn.dataset.tab).classList.add('active');
    });
  });
}
function buildSpecialRows() {
  const host = $('specialParts');
  host.innerHTML = '';
  for (let i=0;i<6;i++) {
    const row=document.createElement('div'); row.className='part-row special-row';
    const sel=document.createElement('select'); sel.className='special-part-name';
    const blank=document.createElement('option'); blank.value=''; blank.textContent=''; sel.appendChild(blank);
    catalog.special_parts.forEach(p=>{const o=document.createElement('option');o.value=p;o.textContent=p;sel.appendChild(o);});
    const desc=document.createElement('input'); desc.className='special-part-description'; desc.readOnly=true;
    const qty=document.createElement('input'); qty.type='number';qty.min='0';qty.step='1';qty.value='';qty.className='special-part-qty';
    const price=document.createElement('input'); price.className='special-part-price'; price.readOnly=true;
    sel.addEventListener('change',()=>{
      const detail=(catalog.special_part_details||{})[sel.value]||{};
      desc.value=detail.description||'';
      price.value=detail.price ? fmtMoney(detail.price) : '';
    });
    row.append(sel,desc,qty,price); host.appendChild(row);
  }
}
function resetQuoteForm() {
  $('customer_name').value = '';
  $('customer_address').value = '';
  $('series').value = '';
  updateMountsForSeries();
  updateBores();
  $('stroke').value = '';
  $('rod_style').value = '';
  $('cushion').value = '';
  $('port_code').value = '';
  $('seal_code').value = '';
  $('dre_input').value = '';
  $('discount_pct').value = '';
  $('standard_rod_boot_qty').value = '';
  ['rod_extension','stop_tube','extra_thread','air_bleed_qty','prox_switch_qty','extra_port_qty','extra_tie_rod_qty','thick_head_qty','legacy_post_discount_add'].forEach(id => $(id).value = '');
  ['stainless_rod','chrome_bore','rod_gland_drain','brass_wiper','ultraox','transducer','prepped_for_transducer','sensor_cover','valve_manifold'].forEach(id => $(id).value = '');
  document.querySelectorAll('[data-accessory]').forEach(inp => inp.value = '');
  document.querySelectorAll('.special-row').forEach(row => {
    row.querySelector('.special-part-name').value = '';
    row.querySelector('.special-part-description').value = '';
    row.querySelector('.special-part-qty').value = '';
    row.querySelector('.special-part-price').value = '';
  });
  $('pressure').value = '';
  $('xi_mt4').value = '';
  $('force_display').value = '';
  $('tie_rod_diameter').value = '';
  $('tie_rod_length').value = '';
  $('tie_rod_cost').value = '';
  $('quote_net_each').value = '$0.00';
  $('profit_display').value = '$0.00';
  $('errorMessage').textContent = '';
  const model = $('model_code'); if (model) model.textContent = '';
}
window.resetQuoteForm = resetQuoteForm;

function payload() {
  const p = {
    series:$('series').value,bore:$('bore').value,rod_diameter:$('rod_diameter').value,mount:$('mount').value,
    stroke:$('stroke').value,cushion:$('cushion').value,port_code:$('port_code').value,seal_code:$('seal_code').value,
    rod_style:Number($('rod_style').value),discount:Number($('discount_pct').value||0)/100,
    dre:String($('dre_input').value||'').trim().toUpperCase()==='Y',
    standard_rod_boot_qty:$('standard_rod_boot_qty').value,
    rod_extension:$('rod_extension').value,stop_tube:$('stop_tube').value,extra_thread:$('extra_thread').value,
    air_bleed_qty:$('air_bleed_qty').value,prox_switch_qty:$('prox_switch_qty').value,extra_port_qty:$('extra_port_qty').value,
    extra_tie_rod_qty:$('extra_tie_rod_qty').value,thick_head_qty:$('thick_head_qty').value,
    legacy_post_discount_add:$('legacy_post_discount_add').value,
    stainless_rod:boolFromYN('stainless_rod'),chrome_bore:boolFromYN('chrome_bore'),rod_gland_drain:boolFromYN('rod_gland_drain'),
    brass_wiper:boolFromYN('brass_wiper'),ultraox:boolFromYN('ultraox'),transducer:boolFromYN('transducer'),
    prepped_for_transducer:boolFromYN('prepped_for_transducer'),sensor_cover:boolFromYN('sensor_cover'),valve_manifold:boolFromYN('valve_manifold'),
    accessory_quantities:{},special_parts:{}
  };
  document.querySelectorAll('[data-accessory]').forEach(inp=>{if(Number(inp.value)>0)p.accessory_quantities[inp.dataset.accessory]=inp.value;});
  document.querySelectorAll('.special-row').forEach(row=>{
    const n=row.querySelector('.special-part-name').value,q=row.querySelector('.special-part-qty').value;
    if(n&&Number(q)>0)p.special_parts[n]=q;
  });
  return p;
}
function showResult(r) {
  $('model_code').textContent=r.model_code;
  $('quote_net_each').value=fmtMoney(r.quote_net_each);
  $('dialog_net_each').textContent=fmtMoney(r.quote_net_each);
  ['quote_list_price','expedited_price','emergency_price','base_price','stroke_cushion','modifications','accessories','special_parts','position_sensing','va_total','dre_surcharge','pre_discount_subtotal','working_net_each'].forEach(k=>$(k).textContent=fmtMoney(r[k]));
  $('display_discount').textContent=(Number($('discount_pct').value||0)).toFixed(2)+'%';
  const box=$('warningsBox'), list=$('warnings'); list.innerHTML='';
  (r.warnings||[]).forEach(w=>{const li=document.createElement('li');li.textContent=w;list.appendChild(li);}); box.hidden=!(r.warnings||[]).length;
  const dlg=$('quoteResultDialog'); if (dlg.showModal) dlg.showModal();
}
async function init() {
  wireTabs();
  try {
    const res=await fetch('/api/catalog'); if(!res.ok) throw new Error('Catalog request failed'); catalog=await res.json();
    fillSelect($('series'),Object.keys(catalog.series),x=>x,true);
    fillSelect($('cushion'),catalog.cushions,x=>x,true); fillSelect($('port_code'),catalog.port_codes,x=>x||'',true); fillSelect($('seal_code'),catalog.seal_codes,x=>x||'',true); fillSelect($('rod_style'),catalog.rod_styles,x=>x,true);
    $('series').addEventListener('change',()=>{updateMountsForSeries();updateBores();}); $('bore').addEventListener('change',updateRods);
    $('dre_input').addEventListener('input',()=>{$('dre_input').value=$('dre_input').value.toUpperCase().replace(/[^Y]/g,'').slice(0,1);});
    updateMountsForSeries(); updateBores(); buildSpecialRows(); resetQuoteForm(); $('engineStatus').textContent='Catalog loaded';
  } catch(e) { $('engineStatus').textContent='Catalog unavailable'; $('errorMessage').textContent=e.message; }
}
$('quoteForm').addEventListener('submit',async e=>{
  e.preventDefault(); $('errorMessage').textContent=''; $('calculateButton').disabled=true; $('calculateButton').textContent='Working...';
  try {
    const res=await fetch('/api/calculate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});
    const body=await res.json(); if(!res.ok||!body.ok)throw new Error(body.error||'Calculation failed'); showResult(body.result);
  } catch(e){$('errorMessage').textContent=e.message;} finally{$('calculateButton').disabled=false;$('calculateButton').textContent='Quote';}
});
init();
