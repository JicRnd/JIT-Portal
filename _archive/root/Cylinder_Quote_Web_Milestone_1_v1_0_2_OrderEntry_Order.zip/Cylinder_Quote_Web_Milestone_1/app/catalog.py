from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import Any

from cylinder_quote_engine.data import PricingData, parse_dimension
from .service import ACCESSORY_NAMES


def _fmt(d: Decimal) -> str:
    s = format(d, "f")
    return s.rstrip("0").rstrip(".") if "." in s else s


def build_catalog(data: PricingData) -> dict[str, Any]:
    combos: dict[str, dict[str, dict[str, set[str]]]] = defaultdict(lambda: defaultdict(lambda: defaultdict(set)))

    for row in data.series_pricing:
        aliases = [x.strip().upper() for x in row.get("series_aliases", "").split("|") if x.strip()]
        bore = _fmt(parse_dimension(row["bore"]))
        rod = _fmt(parse_dimension(row["rod_diameter"]))
        mounts = [x.strip().upper() for x in row.get("mount_codes", "").split("|") if x.strip()]
        for series in aliases:
            combos[series][bore][rod].update(mounts)

    for row in data.va_base:
        bore = _fmt(parse_dimension(row["bore"]))
        rod = _fmt(parse_dimension(row["rod_diameter"]))
        # VA workbook path is selected by series/bore/rod. Mount remains a quote/model input.
        combos["VA"][bore][rod].update({"MX0", "MP1", "MP2", "MP3", "MPU3"})

    catalog = {}
    series_mounts = {}
    for series in sorted(combos):
        catalog[series] = {}
        mount_union = set()
        for bore in sorted(combos[series], key=lambda x: Decimal(x)):
            catalog[series][bore] = {}
            for rod in sorted(combos[series][bore], key=lambda x: Decimal(x)):
                row_mounts = sorted(combos[series][bore][rod])
                catalog[series][bore][rod] = row_mounts
                mount_union.update(row_mounts)
        series_mounts[series] = sorted(mount_union)

    special_parts = sorted({r["part_number"].strip() for r in data.special_parts if r.get("part_number", "").strip()})

    return {
        "series": catalog,
        "series_mounts": series_mounts,
        "accessories": ACCESSORY_NAMES,
        "special_parts": special_parts,
        "cushions": ["NC", "RE", "CE", "BE", "ARE", "ACE", "ABE"],
        "port_codes": ["", "N", "S", "F"],
        "seal_codes": ["", "B", "C", "H", "L", "P", "V"],
        "rod_styles": [
            {"value": 1, "label": "1 - Standard"},
            {"value": 2, "label": "2 - Oversize"},
            {"value": 3, "label": "3 - Alternate standard"},
            {"value": 5, "label": "5 - Special Threads"},
        ],
    }
