# JIT Cylinder Quote Web - Milestone 1

Calculation-only Flask web interface around the frozen Cylinder Quote Pricing Engine v1.2.

## Scope
- OrderEntry-style browser form.
- Cascading Series -> Bore -> Rod -> Mount choices sourced from extracted pricing data.
- Core cylinder inputs, modifications, position sensing, accessories, special parts, and Standard Rod Boot.
- JSON API returns model code, full price breakdown, List, Net Each, Expedited, Emergency, and legacy compatibility warnings.
- No database, quote saving, customer records, quote numbers, authentication, or PDF generation yet.

## Run on Windows
1. Install Python 3.11 or newer.
2. Open PowerShell in this folder.
3. Create a virtual environment: `py -m venv .venv`
4. Activate it: `.\.venv\Scripts\Activate.ps1`
5. Install Flask: `py -m pip install -r requirements.txt`
6. Start the app: `py run.py`
7. Open `http://localhost:5055`

## API
- `GET /api/health`
- `GET /api/catalog`
- `POST /api/calculate`

Example POST body:
```json
{
  "series": "H",
  "bore": "2",
  "rod_diameter": "1",
  "mount": "MX0",
  "stroke": "12",
  "cushion": "NC",
  "port_code": "N",
  "seal_code": "",
  "rod_style": 1,
  "discount": "0.10",
  "dre": false
}
```

The pricing engine remains server-side. Browser JavaScript does not contain authoritative price tables or business arithmetic.
