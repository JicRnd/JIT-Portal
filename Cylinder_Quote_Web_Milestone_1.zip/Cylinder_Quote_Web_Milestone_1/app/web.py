from __future__ import annotations

from pathlib import Path

try:
    from flask import Flask, jsonify, render_template, request
except ModuleNotFoundError as exc:  # pragma: no cover - developer environment may not have Flask installed
    raise RuntimeError("Flask is required for the web layer. Install with: pip install -r requirements.txt") from exc

from .catalog import build_catalog
from .service import calculate_payload, make_engine


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    root = Path(__file__).resolve().parents[1]
    engine = make_engine(root)
    catalog = build_catalog(engine.data)

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "engine": "Pricing Engine v1.2"})

    @app.get("/api/catalog")
    def get_catalog():
        return jsonify(catalog)

    @app.post("/api/calculate")
    def calculate():
        payload = request.get_json(silent=True)
        if payload is None:
            return jsonify({"ok": False, "error": "Expected application/json request body"}), 400
        try:
            result = calculate_payload(engine, payload)
        except (ValueError, LookupError, KeyError) as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "result": result})

    return app
