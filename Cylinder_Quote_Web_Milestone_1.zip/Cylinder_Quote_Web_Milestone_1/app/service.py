from __future__ import annotations

from dataclasses import asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from cylinder_quote_engine import QuoteInputs, QuotePricingEngine
from cylinder_quote_engine.data import parse_dimension

D = Decimal

ACCESSORY_NAMES = [
    "Rod Clevis",
    "Rod Eye",
    "Self-Aligning Male Eye",
    "SA - Clevis Bracket",
    "Alignment Coupler",
    "Male Rod Eye",
    "Eye Bracket",
    "Pivot Pin",
    "Safety Coupler",
    "Rod Stud",
    "Jam Nut",
    "Clevis Bracket",
    "SA - Pivot Pin",
    "Weld Plate",
]

BOOLEAN_FIELDS = {
    "dre",
    "stainless_rod",
    "chrome_bore",
    "rod_gland_drain",
    "brass_wiper",
    "ultraox",
    "transducer",
    "prepped_for_transducer",
    "sensor_cover",
    "valve_manifold",
}

DECIMAL_FIELDS = {
    "bore",
    "rod_diameter",
    "stroke",
    "discount",
    "rod_extension",
    "stop_tube",
    "extra_thread",
    "air_bleed_qty",
    "prox_switch_qty",
    "extra_port_qty",
    "extra_tie_rod_qty",
    "thick_head_qty",
    "standard_rod_boot_qty",
    "legacy_post_discount_add",
    "legacy_reserved_add",
}


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _decimal(value: Any, field_name: str) -> Decimal:
    if value in (None, ""):
        return D("0")
    try:
        return parse_dimension(value)
    except (InvalidOperation, ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"{field_name} must be numeric") from exc


def _mapping_decimals(value: Any, field_name: str) -> dict[str, Decimal]:
    if value in (None, ""):
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"{field_name} must be an object")
    out: dict[str, Decimal] = {}
    for key, raw in value.items():
        qty = _decimal(raw, f"{field_name}.{key}")
        if qty != 0:
            out[str(key)] = qty
    return out


def quote_inputs_from_payload(payload: dict[str, Any]) -> QuoteInputs:
    if not isinstance(payload, dict):
        raise ValueError("request body must be a JSON object")

    required = ["series", "bore", "rod_diameter", "mount", "stroke"]
    missing = [name for name in required if payload.get(name) in (None, "")]
    if missing:
        raise ValueError("missing required fields: " + ", ".join(missing))

    kwargs: dict[str, Any] = {
        "series": str(payload["series"]).strip().upper(),
        "bore": _decimal(payload["bore"], "bore"),
        "rod_diameter": _decimal(payload["rod_diameter"], "rod_diameter"),
        "mount": str(payload["mount"]).strip().upper(),
        "stroke": _decimal(payload["stroke"], "stroke"),
        "cushion": str(payload.get("cushion", "NC")).strip().upper() or "NC",
        "port_code": str(payload.get("port_code", "")).strip().upper(),
        "seal_code": str(payload.get("seal_code", "")).strip().upper(),
        "rod_style": int(payload.get("rod_style", 1) or 1),
        "accessory_quantities": _mapping_decimals(payload.get("accessory_quantities", {}), "accessory_quantities"),
        "special_parts": _mapping_decimals(payload.get("special_parts", {}), "special_parts"),
    }

    for name in BOOLEAN_FIELDS:
        kwargs[name] = _bool(payload.get(name, False))
    for name in DECIMAL_FIELDS:
        if name in {"bore", "rod_diameter", "stroke"}:
            continue
        kwargs[name] = _decimal(payload.get(name, 0), name)

    return QuoteInputs(**kwargs)


def decimal_to_json(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, dict):
        return {k: decimal_to_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [decimal_to_json(v) for v in value]
    return value


def calculate_payload(engine: QuotePricingEngine, payload: dict[str, Any]) -> dict[str, Any]:
    inputs = quote_inputs_from_payload(payload)
    result = engine.calculate(inputs)
    return {k: decimal_to_json(v) for k, v in asdict(result).items()}


def make_engine(project_root: Path) -> QuotePricingEngine:
    return QuotePricingEngine(project_root / "data")
